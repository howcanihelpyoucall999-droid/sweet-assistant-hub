
## Current state (verified from your repo)

Your repo already has a **basic 2-worker fallback** in two TanStack server routes:

- `src/routes/api/public/tryon.ts` — tries `yisol/IDM-VTON` twice, then `Kwai-Kolors/Kolors-Virtual-Try-On`.
- `src/routes/api/public/enhance.ts` — tries `finegrain/finegrain-image-enhancer` twice, then `sczhou/CodeFormer`.

Both use `@gradio/client`, a per-attempt timeout (90s / 120s), and return a 502 JSON only when every worker fails. The client (`src/client/dress-tryon.js`, `src/client/enhance.js`) just POSTs to those endpoints, so **all failover work stays server-side** — no UI/client changes needed.

Note: your message says CodeFormer is the primary enhancer, but the code actually runs Finegrain first and CodeFormer as fallback. I'll keep that order (Finegrain gives higher-fidelity results and CodeFormer stays in the chain) unless you tell me to flip it.

## Simpler free alternative (you asked)

The "busy / queue" errors on `yisol/IDM-VTON` and `sczhou/CodeFormer` almost always come from the public Space being rate-limited across all HF users. The cleanest fix, **no code changes**:

1. Open each Space on huggingface.co → **Duplicate this Space** (free, requires an HF account).
2. Set it to **private** or public, CPU basic is free; for VTON you'll want the ZeroGPU tier (also free, gated by an HF Pro-free quota).
3. Put the duplicated Space IDs (e.g. `your-username/IDM-VTON`) in an env var and point the code at those.

You get dedicated queue capacity and the "busy" problem largely disappears — often eliminating the need for multi-worker failover entirely. I'll wire this in as **configurable primaries via env vars** so you can flip to your own duplicated Spaces later without another code change.

## Plan

### 1. Import Cubit into this Lovable project
Fetch the repo (main branch) and copy every source file into the matching path here, overwriting the blank template (`src/routes/index.tsx`, `src/routes/__root.tsx`, `src/styles.css`, `package.json`, etc.). Public assets (`public/*.png`, garments, logo, manifest) copied as binaries. Then `bun install` picks up `@gradio/client` and the rest of your deps.

### 2. Expand the failover worker chain

**Try-on** (`src/routes/api/public/tryon.ts`) — attempts, in order:
1. `yisol/IDM-VTON` (primary, quality match)
2. `yisol/IDM-VTON` retry after short backoff
3. `Kwai-Kolors/Kolors-Virtual-Try-On` (already there — reliable, free ZeroGPU)
4. `levihsu/OOTDiffusion` (high-quality diffusion VTON, half-body + full-body endpoints)
5. `franciszzj/Leffa` (newer VTON, good garment fidelity, low traffic)

**Enhance** (`src/routes/api/public/enhance.ts`) — attempts, in order:
1. `finegrain/finegrain-image-enhancer` (primary)
2. `finegrain/finegrain-image-enhancer` retry
3. `sczhou/CodeFormer` (quality match for faces)
4. `Xintao/GFPGAN` (face restoration, same family as CodeFormer)
5. `doevent/Face-Real-ESRGAN` (general upscale + face, low traffic)

Each worker gets its own small adapter function (input signature per Space, `client.predict(endpoint, args)`), reusing the existing `extractUrl` / `fetchImageBuffer` / `withTimeout` helpers. Failure of one worker is caught, logged, and the loop moves to the next — user sees no refresh, no manual retry.

### 3. Smarter failure detection
Right now any thrown error triggers the next worker. I'll add lightweight classification so we skip retries that can't succeed:
- **Retry / next worker**: 5xx, timeout, "queue is full", "Space is sleeping", `429`, network errors.
- **Stop immediately**: 4xx from our own validation (bad file type, too big) — return 400 straight to the client, don't burn workers.

### 4. Configurable primaries (opt-in for your duplicated Spaces)
Read optional env vars — `TRYON_PRIMARY_SPACE`, `ENHANCE_PRIMARY_SPACE` — and prepend them to the attempt list when set. Empty/unset = current behavior. Lets you point at your own duplicated Spaces later without another code push.

### 5. Deliverable
Preview updates with the imported Cubit code + expanded failover. Once you approve, I'll also provide a downloadable zip via Lovable's Download Codebase button (top of file tree) — that's the shipping route rather than me generating a zip artifact, since it always matches the live preview.

## Technical notes

- `@gradio/client` `Client.connect` accepts `hf_token` — already wired via `process.env.HF_TOKEN`. The same token works for all listed backups.
- OOTDiffusion has two endpoints (`/process_hd` half-body, `/process_dc` full-body). The adapter will pick `/process_hd` by default (matches IDM-VTON's use case).
- All backup Spaces are public, free-tier, and use the standard gradio predict API — no extra secrets required beyond your existing `HF_TOKEN`.
- No UI changes. `src/client/dress-tryon.js` and `src/client/enhance.js` keep their current fetch calls and error handling.
- The 502 fallback response (`"AI service is busy or unavailable"`) stays as the final safety net when literally every worker fails.

Approve to switch to build mode and I'll run the import + edits in one pass.
